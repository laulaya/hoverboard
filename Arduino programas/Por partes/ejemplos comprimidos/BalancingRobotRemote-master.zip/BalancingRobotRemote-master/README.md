# This project is deprecated

This project is no longer maintained as I will instead focus on a Balancing robot kit, the Balanduino. For more information see the new repository: <https://github.com/TKJElectronics/Balanduino> and the Kickstarter campaign: <http://www.kickstarter.com/projects/tkjelectronics/balanduino-balancing-robot-kit>.

<br>

The code is released under the GNU General Public License.

This is the remote control code, I use it to control my balancing robot. See code at: <http://mbed.org/users/Lauszus/programs/BalancingRobotPS3/>. The Arduino use the PS3 Controller Bluetooth Library for Arduino i created: <https://github.com/TKJElectronics/USB_Host_Shield_2.0>. It's pretty simple. It just sends the data via the serial port to the mbed, when then reacts to the commands.

For more information see my blog post at <http://blog.tkjelectronics.dk/2012/03/the-balancing-robot/> or send me an email at: <kristianl@tkjelectronics.dk>.

Also check out the youtube video of it in action: <http://www.youtube.com/watch?v=N28C_JqVhGU>.